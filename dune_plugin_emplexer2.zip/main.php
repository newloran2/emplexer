<?php
///////////////////////////////////////////////////////////////////////////

define('ROOT_PATH', __DIR__);

require_once 'lib/default_dune_plugin_fw.php';
require_once 'AutoLoad.php';
  error_reporting(E_ALL);
 ini_set('display_errors', 1);


DefaultDunePluginFw::$plugin_class_name = 'Emplexer';

///////////////////////////////////////////////////////////////////////////
?>
