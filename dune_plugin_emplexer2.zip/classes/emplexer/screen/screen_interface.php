<?php

interface ScreenInterface {
    public function generateScreen();
}

?>