<?php 

/**
* 
*/
class PlexSource
{
	
	private $ip;
	private $port;
	private $name;
	private $token

	function __construct($url, $name = null)
	{
		
	}
}

?>