<a  href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=newloran2%40gmail%2ecom&lc=US&item_name=emplexer&item_number=emplexer%20donation&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted"><img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" alt="PayPal - The safer, easier way to pay online!"/></a>

emplexer 2.0
========


This is a total rewrite for emplexer plugin <a href="https://github.com/newloran2/emplexer/blob/master/README.md">emplexer plugin</a>.

create in the root directory "/" on this disc, a directory called dune_plugins.
download the  <a href="https://github.com/newloran2/emplexer/archive/2.0.zip">2.0 branch</a>
extract this file to the directory you created earlier.
the directory resulting from the extraction should be called emplexer2.
With this disk will have the following structure / dune_plugins/emplexer2.

Restart the dune and a new icon will be created in the applications menu called emplexer 2.
