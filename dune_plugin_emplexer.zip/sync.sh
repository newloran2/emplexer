rsync -ravzp  /Users/erik/Dropbox/Projeto/Dune/emplexer.git/*  /Volumes/New_Volume_2e00f32100f2ef29/dune_plugins/emplexer/

