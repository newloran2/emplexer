<?php


define('TRANSCODE_ENDPOINT','/video/:/transcode/universal/');
define('TRANSCODE_STARTS_SESSION_ENDPOINT',TRANSCODE_ENDPOINT . 'start.m3u8');

/**
* Manager all transcoded sessions
*/
class TranscodeManager
{
    private $plexLocation;
    private $subtitleSize=75;
    private $session= 'CF0CA653-216A-428E-8412-DA8515BAA5C6';
    private $protocol = 'hls';
    private $audioBoost = 100;
    private $offset = 0;
    private $directStream=1;
    private $directPlay=1;
    private $tg=0; //3g
    private $videoResolution='1920x1080'; //using the maximum resolution and let plex to select if it's correct
    private $maxVideoBitrate='40000';
    private $videoQuality=100;
    private $xPlexDevice='iPhone';
    private $xPlexVersion= '3.2.3';
    private $xPlexClientPlatform='DuneHD';
    private $xPlexDeviceName='iPad%20de%20Erik%20Clemente';
    private $xPlexModel='4%2C1';
    private $xPlexPlatform='iOS';
    private $xPlexClientIdentifier='CF0CA653-216A-428E-8412-DA8515BAA5C6';
    private $xPlexProduct= 'Plex%2FiOS';
    private $xPlexPlatformVersion='6.1.2';
    private $xPlexClientCapabilities = 'protocols=shoutcast,http-video;videoDecoders=MPEG4{profile:asp&resolution:1080&level:0.5};audioDecoders=wav';

    private static $instance;

    public static function getInstance($plexIp, $plexPort=32400){
        if (!isset(self::$instance)){
            self::$instance = new TranscodeManager($plexIp, $plexPort);
        }
        return self::$instance;
    }


    private function __construct($plexIp, $plexPort=32400) {
       $this->plexLocation = "http://$plexIp:$plexPort";
    }

    public function startSession($urlToEncode, $offset=0){
        $url = "$this->plexLocation". TRANSCODE_STARTS_SESSION_ENDPOINT .  "?subtitleSize=$this->subtitleSize&session=$this->session&path=$urlToEncode&protocol=$this->protocol&audioBoost=$this->audioBoost&offset=$offset&directStream=$this->directStream&directPlay=$this->directPlay&3g=$this->tg&videoResolution=$this->videoResolution&maxVideoBitrate=$this->maxVideoBitrate&videoQuality=$this->videoQuality&X-Plex-Device=$this->xPlexDevice&X-Plex-Version=$this->xPlexVersion&X-Plex-Client-Platform=$this->xPlexClientPlatform&X-Plex-Device-Name=$this->xPlexDeviceName&X-Plex-Model=$this->xPlexModel&X-Plex-Platform=$this->xPlexPlatform&X-Plex-Client-Identifier=$this->xPlexClientIdentifier&X-Plex-Product=$this->xPlexProduct&X-Plex-Platform-Version=$this->xPlexPlatformVersion";
        echo __METHOD__ . " URL = $url";
        $start = $this->httpGet($url);
        $start = explode("\n", $start);

        $base = dirname($start[count($start) -2]);


        $url = $this->plexLocation . TRANSCODE_ENDPOINT . $start[count($start)-2];

        $basePlayList = $this->httpGet($url);

        //the dune won't read playlists with relative path, fix that to work
        $b =$this->plexLocation . TRANSCODE_ENDPOINT . $base;
        $a = preg_replace('/(.*.ts)/i',  "$b/$1"  , $basePlayList);
        return $a;
    }

    public function stopSession(){
        $url = $this->plexLocation . TRANSCODE_ENDPOINT . 'stop?session=' . $this->session;
        // echo "url = $url";
        $this->httpGet($url);
    }



    /**
    *util to get any http resource
    **/
    private function httpGet($url) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,    20);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,    true);
        curl_setopt($ch, CURLOPT_TIMEOUT,           20);
        curl_setopt($ch, CURLOPT_USERAGENT,         'DuneHD/1.0');
        curl_setopt($ch, CURLOPT_URL,               $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION,    true);
        curl_setopt($ch, CURLOPT_MAXREDIRS,         10);


       $emplexerClientHeaders = array(
           // 'X-Plex-Client-Capabilities: protocols=http-live-streaming,http-mp4-streaming,http-streaming-video,http-streaming-video-720p,http-mp4-video,http-mp4-video-720p,http-mkv-video-720p;videoDecoders=h264{profile:high&resolution:1080&level:51};audioDecoders=mp3,aac,vob,wav'
           "X-Plex-Client-Capabilities: $this->xPlexClientCapabilities"
       );
////
       curl_setopt($ch, CURLOPT_HTTPHEADER, $emplexerClientHeaders);
//        curl_setopt($ch, CURLOPT_HEADER, true);
//        curl_setopt($ch, CURLINFO_HEADER_OUT, true);

        $content = curl_exec($ch);



        return $content;

//
//




    }
}


// $trans = new TranscodeManager('192.168.2.8');

// $trans->startSession(urlencode('http://192.168.2.8:32400/library/metadata/32512'));

//echo TranscodeManager::getInstance('192.168.2.8')->startSession(urlencode('http://192.168.2.8:32400/library/metadata/21639'));
// TranscodeManager::getInstance('192.168.2.8')->stopSession();
 ?>