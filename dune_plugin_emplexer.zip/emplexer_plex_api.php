<?php

include_once 'lib/utils.php';

function getBasicAuthToken($user, $password)
{
    $token = "$user:$password";
    return 'Basic' . base64_encode($token);
}


function myPlexLogin($user, $password )
{
    $auth = getBasicAuthToken($user, $password);
    $url = 'https://my.plexapp.com/users/sign_in.xml';

    $headers =  array("Authorization: $auth", "X-Plex-Client-Identifier: jshdjhs-sjdhsjdh-jsjhdsdsd-jhsjhds", "X-Plex-Platform: DuneHD", "X-Plex-Provides: player", "X-Plex-Product: emplexer");
    $opts = array(CURLOPT_HTTPHEADER, $headers);

    $a = HD::http_post_document($url, null, $opts);
    echo $a;
}


function get()
{
    $auth = getBasicAuthToken('newloran2@gmail.com', 'bastard123');
    $url = 'https://my.plexapp.com/users/sign_in.xml';

    $ch = curl_init();

        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,    20);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,    true);
        curl_setopt($ch, CURLOPT_TIMEOUT,           20);
        curl_setopt($ch, CURLOPT_USERAGENT,         'DuneHD/1.0');
        curl_setopt($ch, CURLOPT_URL,               $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION,    true);
        curl_setopt($ch, CURLOPT_MAXREDIRS,         10);
        curl_setopt($ch, CURLOPT_POST,         true);
        $postFields = array("authenticity_token" => $auth, 'user[login]' => 'newloran2' , 'user[password]' => 'bastard123');
        curl_setopt($ch, CURLOPT_POSTFIELDS,         $postFields);
        $headers =  array("authenticity_token: $auth", "X-Plex-Client-Identifier: jshdjhs-sjdhsjdh-jsjhdsdsd-jhsjhds", "X-Plex-Platform: DuneHD", "X-Plex-Provides: player", "X-Plex-Product: emplexer");
        curl_setopt($ch, CURLOPT_HTTPHEADER,         $headers);

        $content = curl_exec($ch);
        echo $content;
}

get();
 ?>