<?php 

class EmplexerActionFactory 
{
	public static function show_configuration_modal($title, &$plugin_cookies, $post_action= nul){


		ControlFactory::add_text_field(
				$defs,
				$name          = "plexIp",
				$title         = "Plex IP",
				$initial_value = $plexIp,
				$numeric       = false,
				$password      = false,
				$has_osk       = false,
				$always_active = 0,
				$width         = 500 
			);

			ControlFactory::add_text_field(
				$defs,
				$name          = "plexPort",
				$title         = "Plex Port",
				$initial_value = $plexPort,
				$numeric       = true,
				$password      = false,
				$has_osk       = false,
				$always_active = 0,
				$width         = 500     
			);

			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,
            'btnSalvar', 'save', 200, $post_action);


			return ActionFactory::show_dialog($title, $defs);
	}
}
 ?>