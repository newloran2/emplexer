emplexer
========

This is a work in progress plugin to integrate Dune Media Player with PLex Media server.

All the filters of the PMS are accessible for Films and Series, and much more are planed.
