<?php 
	phpinfo();
 ?>